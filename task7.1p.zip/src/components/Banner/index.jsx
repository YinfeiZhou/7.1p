import React from 'react';
import styles from "./index.module.less"

function Banner(props) {
    return (
        <div className={styles.banner}>
            <img className={styles.banner_img} src="/images/top.jpeg" alt=""/>
            <div className={styles.banner_title}> Hey, I am Victor.
            </div>
        </div>

    );
}

export default Banner;