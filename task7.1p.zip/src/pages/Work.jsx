import React from 'react';

function Work(props) {
    return (
        <div></div>
    );
}

export default Work;